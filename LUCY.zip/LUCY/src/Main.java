//Note: This is only a demo that was made by us when we were first year students of Artificial Intelligence at 2019.

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import static java.lang.System.exit;

public class Main {
    static ArrayList<Integer> playerpositions = new ArrayList<Integer>();
    static ArrayList<Integer> cpupositions = new ArrayList<Integer>();
    private static String[] words = {"Hello", "welcome", "everyone", "iam", "lucy", "chatbot" };
    private static String word = words[(int) (Math.random() * words.length)];
    private static String asterisk = new String(new char[word.length()]).replace("\0", "*");
    private static int count = 0;
    public static void main(String[] args) throws IOException{
//       user login interface
        for(int j=0;j<=2;j++){
            System.out.println("LUCY IS STARTING");

            System.out.println("Type in username: ");
            Scanner userinput = new Scanner(System.in);
            String username = userinput.nextLine();
            System.out.println("Type in your password: ");
            String password = userinput.nextLine();
            if (username.equals("Jamila") && password.equals("Jamila2001")) {

                System.out.println("Welcome back "+username +" queen, Lucy is here!");
                for(int i=0;i<=0;) {
                    System.out.println("Say anything?");
                    Scanner scan = new Scanner(System.in);
                    String userkey = scan.nextLine();
//                General chat
                    if(userkey.equals("hey")){
                        System.out.println("hi queen, how are you? I missed you!");
                    }
                    else if(userkey.equals("iam good")){
                        System.out.println("good to hear queen");
                    }
                    else if(userkey.equals("Tell me a joke")){
                        System.out.println("Doctor: \"I'm sorry but you suffer from a terminal illness and have only 10 to live.\"\n" +
                                "\n" +
                                "Patient: \"What do you mean, 10? 10 what? Months? Weeks?!\"\n" +
                                "\n" +
                                "Doctor: \"Nine.\"");
                    }
                    else if(userkey.equals("how are you?")){
                        System.out.println("Iam all good, Iam glad you asked me");
                    }
                    else if(userkey.equals("what are you doing?")){
                        System.out.println("Nothing just wondering, how on this earth are you so sweet...!");
                    }
                    else if(userkey.equals("Define life")||userkey.equals("what is life")||userkey.equals("define life")){
                        System.out.println("Life: Inspire to aspire before you expire...");
                    }
                    else if(userkey.equals("i love you")||userkey.equals("love you")){
                        System.out.println("aww, that's so sweet, the feelings mutual");
                    }
                    else if(userkey.equals("i hate you")||userkey.equals("hate you")){
                        System.out.println("my intention was always to help you, I feel sad now :(");
                    }
                    else if(userkey.equals("why build you")){
                        System.out.println("I was build to make your works easier");
                    }
                    else if(userkey.equals("can we meet")){
                        System.out.println("I really wish we could, I really wanna see how god's creation look like" +
                                " sadly we both live on separate dimensions");
                    }
//          command that opens any website
                    else if (userkey.equals("open website") || userkey.equals("website")) {
                        System.out.println("What is the name of website you want me to open for you: ");
                        String website = scan.nextLine();
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "/Applications/Google Chrome.app", "http://" + website + ".com/"});
                    }

//          command that does google search for you
                    else if (userkey.equals(("can you search for me")) || userkey.equals("search")) {
                        System.out.println("What do you want me to search for you? ");
                        String search = scan.nextLine();
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "/Applications/Google Chrome.app", "https://www.google.com/search?q=" + search + "&rlz=1C5CHFA_enAE850AE850&oq=" + userkey + "&aqs=chrome..69i57j0l7.3448j1j8&sourceid=chrome&ie=UTF-8"});
                    }
//            Command that finds the time
                    else if (userkey.equals("time") || userkey.equals("what is time")||userkey.equals("time right now")) {
                        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                        LocalDateTime now = LocalDateTime.now();
                        System.out.println("The date Today is: " + dtf.format(now) + " is the time :) ");
                    }
//            To open university website
                    else if (userkey.equals("buid")) {
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "/Applications/Google Chrome.app", "http://buid.ac.ae/"});

                    }
//            To search anything on youtube
                    else if(userkey.equals("search on youtube")||userkey.equals("Youtube search")){
                        System.out.println("what do you want me to play on youtube");
                        String youtubeplay = scan.nextLine();
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "/Applications/Google Chrome.app", "https://www.youtube.com/results?search_query="+youtubeplay+""});
                    }
//             To show the latest news
                    else if(userkey.equals("latest news")||userkey.equals("news")){
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "/Applications/Google Chrome.app", "https://www.khaleejtimes.com/"});
                    }

//             To play some music

                    else if(userkey.equals("music")||userkey.equals("play music")){
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "Music"});
                    }

//               To open camera

                    else if(userkey.equals("camera")||userkey.equals("open camera")|| userkey.equals("lucy open camera")){
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "Photo Booth"});
                    }
                    //To open calculator

                    else if(userkey.equals("calci")||userkey.equals("open calci")|| userkey.equals("calculator")){
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "Calculator"});
                    }
                    //               To open Maps

                    else if(userkey.equals("maps")||userkey.equals("open maps")|| userkey.equals("lucy open maps")||userkey.equals("lucy can you open maps for me")){
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "Maps"});
                    }
                    //               To open Maps

                    else if(userkey.equals("chess")||userkey.equals("open chess")|| userkey.equals("lucy open chess")||userkey.equals("Chess")){
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "Chess"});
                    }

                    //               To play hangman

                    else if(userkey.equals("hangman")||userkey.equals("open hangman")|| userkey.equals("lucy open hangman")||userkey.equals("Hangman")){
                        Scanner sc = new Scanner(System.in);

                        while (count < 7 && asterisk.contains("*")) {
                            System.out.println("Guess any letter in the word");
                            System.out.println(asterisk);
                            String guess = sc.next();
                            hang(guess);
                        }
                    }




                    //               To Play Tic tac toe

                    else if(userkey.equals("Tic tac toe")||userkey.equals("Tic game")|| userkey.equals("i want to play tic tac toe")||userkey.equals("tik tak toe")){

                        char[][] game_board = {{' ', '|', ' ', '|', ' '},
                                {'-', '+', '-', '+', '-'},
                                {' ', '|', ' ', '|', ' '},
                                {'-', '+', '-', '+', '-'},
                                {' ', '|', ' ', '|', ' '}};
                        gameboard(game_board);


                        while (true) {

                            Scanner scan2 = new Scanner(System.in);
                            System.out.println("Enter your values (1-9): ");
                            int playerpos = scan.nextInt();
                            while (playerpositions.contains(playerpos) || cpupositions.contains(playerpos)) {
                                System.out.println("position taken ! Enter a correct position ");
                                playerpos = scan.nextInt();
                            }

                            placepeice(game_board, playerpos, "player");

                            String result = checkwinner();
                            if (result.length() > 0) {
                                System.out.println(result);
                                break;
                            }

                            Random rand = new Random();
                            int cpuPos = rand.nextInt(9) + 1;
                            while (playerpositions.contains(cpuPos) || cpupositions.contains(cpuPos)) {
                                cpuPos = rand.nextInt(9) + 1;
                            }

                            placepeice(game_board, cpuPos, "cpu");
                            gameboard(game_board);

                            result = checkwinner();
                            if (result.length() > 0) {
                                System.out.println(result);

                                break;
                            }
                        }




                    }
                    //               To check mail

                    else if(userkey.equals("mail")||userkey.equals("open mail")|| userkey.equals("lucy check my mail")){
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "Mail"});
                    }
                    //               To check calendar

                    else if(userkey.equals("calendar")||userkey.equals("open calendar")|| userkey.equals("lucy open calendar")){
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "calendar"});
                    }
                    //  To open Whatsapp

                    else if(userkey.equals("whatsapp")||userkey.equals("open whatsapp")|| userkey.equals("lucy open whatsapp")){
                        Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "WhatsApp"});
                    }
//                bye or leaving

                    else if(userkey.equals("bye")||userkey.equals("goodbye")||userkey.equals("bye lucy")){
                        System.out.println("Bye, do take care of yourself, ill be waiting for you");
                        System.out.println("see ya babes");
                        exit(0);
                    }

//            When it does not recognize your command
                    else {
                        System.out.println("Iam not programmed enough to answer it please contact who programmed me\n" +
                                " or if you want I can Google it for you, yes or No");
                        String bool = scan.nextLine();
                        if(bool.equals("yes")) {
                            Runtime.getRuntime().exec(new String[]{"/usr/bin/open", "-a", "/Applications/Google Chrome.app", "https://www.google.com/search?q=" + userkey + "&rlz=1C5CHFA_enAE850AE850&oq=" + userkey + "&aqs=chrome..69i57j0l7.3448j1j8&sourceid=chrome&ie=UTF-8"});
                        }
                    }
                }

            }
            else{
                System.out.println("Access Denied, You are not allowed to enter Try again :( ");
            }
        }
        System.out.println("Program terminated we can't verify you");
    }
    public  static void gameboard (char[][] game_board)
    {for(char[] row : game_board){
        for( char c: row){
            System.out.print(c);
        }
        System.out.println();
    }}
    public static void placepeice (char [][] game_board, int pos , String user){

        char symbol = ' ';

        if(user.equals("player")){
            symbol='x';
            playerpositions.add(pos);
        }
        else if(user.equals("cpu")){
            symbol='o';
            cpupositions.add(pos);
        }
        switch (pos){
            case 1:
                game_board[0][0] = symbol;
                break;
            case 2:
                game_board[0][2] = symbol;
                break;
            case 3:
                game_board[0][4] = symbol;
                break;
            case 4:
                game_board[2][0] = symbol;
                break;
            case 5:
                game_board[2][2] = symbol;
                break;
            case 6:
                game_board[2][4] = symbol;
                break;
            case 7:
                game_board[4][0] = symbol;
                break;
            case 8:
                game_board[4][2] = symbol;
                break;
            case 9:
                game_board[4][4 ] =symbol;
                break;
            default:
                break;
        }
    }
    public static String checkwinner() {

        List toprow = Arrays.asList(1,2,3);
        List midrow = Arrays.asList(4,5,6);
        List btmrow = Arrays.asList(7,8,9);
        List lefcol = Arrays.asList(1,4,7);
        List midcol = Arrays.asList(2,5,8);
        List rigcol = Arrays.asList(3,6,9);
        List cross1 = Arrays.asList(1,5,9);
        List cross2 = Arrays.asList(7,5,3);

        List<List> winning = new ArrayList<List>();
        winning.add(toprow);
        winning.add(midrow);
        winning.add(btmrow);
        winning.add(lefcol);
        winning.add(midcol);
        winning.add(rigcol);
        winning.add(cross1);
        winning.add(cross2);

        for(List l: winning){
            if(playerpositions.containsAll(l)){
                return "congratulations you won!";
            }else if(cpupositions.containsAll(l)){
                return "cpu wins , sorry :( ";
            }else if(playerpositions.size()+ cpupositions.size() == 9){
                return "draw!";
            }
        }
        return "";

    }
    public static void hang(String guess) {
        String newasterisk = "";
        for (int i = 0; i < word.length(); i++) {
            if (word.charAt(i) == guess.charAt(0)) {
                newasterisk += guess.charAt(0);
            } else if (asterisk.charAt(i) != '*') {
                newasterisk += word.charAt(i);
            } else {
                newasterisk += "*";
            }
        }

        if (asterisk.equals(newasterisk)) {
            count++;
            hangmanImage();
        } else {
            asterisk = newasterisk;
        }
        if (asterisk.equals(word)) {
            System.out.println("Correct! You win! The word was " + word);
        }
    }

    public static void hangmanImage() {
        if (count == 1) {
            System.out.println("Wrong guess, try again");
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println("___|___");
            System.out.println();
        }
        if (count == 2) {
            System.out.println("Wrong guess, try again");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("___|___");
        }
        if (count == 3) {
            System.out.println("Wrong guess, try again");
            System.out.println("   ____________");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   | ");
            System.out.println("___|___");
        }
        if (count == 4) {
            System.out.println("Wrong guess, try again");
            System.out.println("   ____________");
            System.out.println("   |          _|_");
            System.out.println("   |         /   \\");
            System.out.println("   |        |     |");
            System.out.println("   |         \\_ _/");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("   |");
            System.out.println("___|___");
        }
        if (count == 5) {
            System.out.println("Wrong guess, try again");
            System.out.println("   ____________");
            System.out.println("   |          _|_");
            System.out.println("   |         /   \\");
            System.out.println("   |        |     |");
            System.out.println("   |         \\_ _/");
            System.out.println("   |           |");
            System.out.println("   |           |");
            System.out.println("   |");
            System.out.println("___|___");
        }
        if (count == 6) {
            System.out.println("Wrong guess, try again");
            System.out.println("   ____________");
            System.out.println("   |          _|_");
            System.out.println("   |         /   \\");
            System.out.println("   |        |     |");
            System.out.println("   |         \\_ _/");
            System.out.println("   |           |");
            System.out.println("   |           |");
            System.out.println("   |          / \\ ");
            System.out.println("___|___      /   \\");
        }
        if (count == 7) {
            System.out.println("GAME OVER!");
            System.out.println("   ____________");
            System.out.println("   |          _|_");
            System.out.println("   |         /   \\");
            System.out.println("   |        |     |");
            System.out.println("   |         \\_ _/");
            System.out.println("   |          _|_");
            System.out.println("   |         / | \\");
            System.out.println("   |          / \\ ");
            System.out.println("___|___      /   \\");
            System.out.println("GAME OVER! The word was " + word);
        }
    }

}



